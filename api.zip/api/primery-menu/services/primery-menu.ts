/**
 * primery-menu service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::primery-menu.primery-menu');
