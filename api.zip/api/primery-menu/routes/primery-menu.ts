/**
 * primery-menu router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::primery-menu.primery-menu');
