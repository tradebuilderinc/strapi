/**
 * primery-menu controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::primery-menu.primery-menu');
