/**
 * manhattan-upper-east-side service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::manhattan-upper-east-side.manhattan-upper-east-side');
