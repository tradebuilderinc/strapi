/**
 * manhattan-upper-east-side router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::manhattan-upper-east-side.manhattan-upper-east-side');
