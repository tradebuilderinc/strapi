/**
 * manhattan-upper-east-side controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::manhattan-upper-east-side.manhattan-upper-east-side');
