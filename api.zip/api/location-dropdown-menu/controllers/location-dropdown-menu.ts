/**
 * location-dropdown-menu controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::location-dropdown-menu.location-dropdown-menu');
