/**
 * location-dropdown-menu service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::location-dropdown-menu.location-dropdown-menu');
