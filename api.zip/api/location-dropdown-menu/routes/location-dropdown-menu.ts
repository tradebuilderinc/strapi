/**
 * location-dropdown-menu router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::location-dropdown-menu.location-dropdown-menu');
