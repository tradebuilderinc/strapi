/**
 * suffolk-county-service controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::suffolk-county-service.suffolk-county-service');
