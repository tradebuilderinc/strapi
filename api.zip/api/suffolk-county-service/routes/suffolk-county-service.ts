/**
 * suffolk-county-service router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::suffolk-county-service.suffolk-county-service');
