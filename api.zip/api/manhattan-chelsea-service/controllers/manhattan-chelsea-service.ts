/**
 * manhattan-chelsea-service controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::manhattan-chelsea-service.manhattan-chelsea-service');
