/**
 * manhattan-chelsea-service service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::manhattan-chelsea-service.manhattan-chelsea-service');
