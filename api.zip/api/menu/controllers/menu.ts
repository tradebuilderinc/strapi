/**
 * menu controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::menu.menu');
