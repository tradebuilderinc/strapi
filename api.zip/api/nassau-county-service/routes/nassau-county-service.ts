/**
 * nassau-county-service router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::nassau-county-service.nassau-county-service');
