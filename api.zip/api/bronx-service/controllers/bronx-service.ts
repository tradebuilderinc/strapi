/**
 * bronx-service controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::bronx-service.bronx-service');
