/**
 * queens-service service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::queens-service.queens-service');
